"""
Lumon Industries -- batch file protection (internal, rev 2).

Every batch file is protected with this module before it leaves the severed
floor.  The key is three register seeds (a, b, c); it is not stored here.
"""

BANNER = b"LUMON INDUSTRIES // MACRODATA REFINEMENT // BATCH FILE // SEVERED FLOOR ONLY\n"


class LFSR:
    """Fibonacci LFSR.  State bit i is s_i; the output is s_0 and the new bit is
    s_0 XOR (the s_j named in `taps`).  That is the recurrence of
    x^length + sum(x^j for j in taps) + 1, which is primitive for the three
    registers below."""

    def __init__(self, length, taps, seed):
        assert 0 < seed < (1 << length)
        self.length, self.state = length, seed
        self.mask = 1 | sum(1 << j for j in taps)

    def bit(self):
        out = self.state & 1
        fb = bin(self.state & self.mask).count("1") & 1
        self.state = (self.state >> 1) | (fb << (self.length - 1))
        return out


def keystream_bits(key, n):
    a, b, c = key
    ra = LFSR(29, [2], a)
    rb = LFSR(31, [28], b)
    rc = LFSR(28, [3], c)
    for _ in range(n):
        x, s, y = ra.bit(), rb.bit(), rc.bit()
        yield x if s else y          # the middle register picks one of the outer two


def keystream(key, nbytes):
    bits = keystream_bits(key, 8 * nbytes)
    out = bytearray()
    for _ in range(nbytes):
        byte = 0
        for _ in range(8):
            byte = (byte << 1) | next(bits)
        out.append(byte)
    return bytes(out)


def seal_batch(key, body):
    data = BANNER + body
    return bytes(p ^ k for p, k in zip(data, keystream(key, len(data))))


def open_batch(key, blob):
    data = bytes(c ^ k for c, k in zip(blob, keystream(key, len(blob))))
    assert data.startswith(BANNER), "wrong key"
    return data[len(BANNER):]
